Tata usaha
username = 196307131987012001
password = 12345678

Guru
username = 195802251982031004
password = 12345678

Kepsek
username = 196103231985011003
password = 12345678

Admin 
username = 000000000000004
password = 12345678





