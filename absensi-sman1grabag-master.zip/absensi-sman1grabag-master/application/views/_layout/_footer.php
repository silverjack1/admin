<footer class="main-footer">
	<!-- To the right -->
	<div class="pull-right hidden-xs">
		<strong>Informatika Undip 2017</strong>
	</div>
	<!-- Default to the left -->
	<strong>Copyright &copy; 2020</strong>
</footer>