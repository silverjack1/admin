# ujian-online-ci

Aplikasi Ujian Online Menggunakan CodeIgniter

<h1>Catatan</h1>
<p>Disarankan upgrade PHP ke versi terbaru (7.3 atau lebih tinggi)</p>

<h1>Cara Install</h1>
    Buat database dengan nama <kbd>ci_online_test</kbd>. Kemudian import database pada folder <kbd>sql</kbd>. Jangan lupa setting lagi file <kbd>config.php</kbd> nya. 
    dan juga ubah date_default_timezone_set pada config.php sesuai dgn waktu daerah masing-masing.<br/>

jika sudah mengikuti langkah diatas dengan benar seharusnya aplikasi sudah berjalan dengan baik. Pastikan pada console browser tidak terdapat error.

<h3>User</h3>
<ul>
<li>Administrator <br/> Email: admin@admin.com <br/> Password : password </li>
  
</ul>

Thanks to :

<ul>
  <li>AdminLTE</li>
<li>CodeIgniter</li>
<li>Ion Auth</li>
<li>Datatables</li>
<li>Ignited Datatables</li>
<li>Select2</li>
<li>SweetAlert2</li>
<li>Bootstrap</li>
<li>JQuery</li>
<li>PACE.js</li>
<li>Codemirror</li>
<li>Bootstrap datetime-picker</li>
<li>Fontawesome</li>
<li>Ion-icons</li>
<li>Froala Editor</li>
<li>MommentJs</li>
<li>ICheck</li>
<li>frankyradio</li>
<li>and more...</li>
</ul>
